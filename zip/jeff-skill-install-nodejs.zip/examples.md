# Examples

The following code snippet below should print "Hello, world!".

```
console.log("Hello, world!");
```
