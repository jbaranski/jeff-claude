# Reference

The Node.js documentation can be found at https://nodejs.org/docs/latest/api/. You will need to find the latest LTS version documentation as that will not load by default. Always refer to the latest LTS documentation if you need to look anything up.
